//: [Previous](@previous)

import Foundation
struct Temperature {
    static var boilingPoint:Int = 100
    var celsius:Int = 10
    static func show() {
        print(boilingPoint)
    }
}

Temperature.boilingPoint
Temperature.boilingPoint = 200
Temperature.boilingPoint
Temperature.show()

let smallerNumber = Double.minimum(100, 200)
print(smallerNumber)

Double.minimum(666, 667)

//: [Next](@next)
