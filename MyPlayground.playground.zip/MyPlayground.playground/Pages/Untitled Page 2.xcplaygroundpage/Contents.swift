//: [Previous](@previous)

import Foundation
struct Odometer {
    var count:Int = 10
    mutating func increment(){
        count = count + 1
    }
    mutating func reset(){
        count = 0
    }
}
var odometer = Odometer()
var secondOdometer = odometer
odometer.increment()
secondOdometer.count
odometer.count
print(odometer.count)
odometer.increment()
print(odometer.count)
odometer.reset()
print(odometer.count)

//: [Next](@next)
