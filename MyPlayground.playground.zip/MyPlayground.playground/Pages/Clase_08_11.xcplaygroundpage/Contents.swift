func function () {
    
}

let imprimirClosure2 = {(String: String) -> String in
    print(String)
    return String
}

/* Estructura Closures
 
 {
    (Parámetros) -> tipo de valor de retorno in
    Código
    return (if needed)
 }
 
 Siempre se tiene que almacenar en una constante:)
*/
 
func promedio(ComputoMovil materiaUno: Double, Seguridad materiaDos: Double, Distribuidos materiaTres: Double) -> Double {
    return (materiaUno + materiaDos + materiaTres) / 3
}

let promedioClosure = {(materiaUno: Double, materiaDos: Double, materiaTres: Double) -> Double in
    return (materiaUno + materiaDos + materiaTres) / 3
}

promedioClosure(10, 10, 9)

// Funcionan muy cool ;O no se llaman como las func
print("Mi promedio es \(promedioClosure(10, 10, 9))")

// Sort

var numeroVoluntarios = [1, 3, 40, 2, 34, 77, 13]

let acomodarVoluntarios = numeroVoluntarios.sort{(primerElemento: Int, segundoElemento: Int) -> Bool in
    return primerElemento < segundoElemento
    
}

let names1 = ["Sofi", "Diego", "Malinalli", "Andreé"]
var fullNames1: [String] = []

for name in names1 {
    let fullName = name + " Mora"
    fullNames1.append(fullName)
}

let names2 = ["Sofi", "Diego", "Malinalli", "Andreé"]

let fullNames2 = names2.map {(name) -> String in
    return name + " Mora"
}

let fullNames3 = names2.map{$0 + " Smith"}

// Filter

let num = [2, 3, 22, 40, 43, 1, 44, 53]

var menosDe20: [Int] = []

for numero in num {
    if numero < 20{
        menosDe20.append(numero)
    }
}

var menosDe20A = num.filter{$0 < 20}

print(menosDe20A)

