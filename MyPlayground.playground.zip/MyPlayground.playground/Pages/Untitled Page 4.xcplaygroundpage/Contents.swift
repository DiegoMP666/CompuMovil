//: [Previous](@previous)

import Foundation
struct Temperature {
    var celsius: Double
    var fahrenheit: Double {
        return celsius * 1.8 + 32
    }
    var kelvin: Double {
        return celsius + 273.15
    }
}

var currentTemperature = Temperature(celsius: 0)
print(currentTemperature.celsius)
print(currentTemperature.fahrenheit)
print(currentTemperature.kelvin)
currentTemperature.celsius = 10
print(currentTemperature.celsius)
print(currentTemperature.fahrenheit)
print(currentTemperature.kelvin)

//currentTemperature.fahrenheit = 10

//: [Next](@next)
