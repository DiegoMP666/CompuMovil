import UIKit

var str:String
str = "Moda y Sofi"
print(str)
var str2 = "no querian entrar"
var number1 = 12
var number2 = 15
var result = number1 + number2
var strResult = str + " " + str2
var strResult2 = "\(str2), \(str) 🤖"
var 😭 = "autosuisuidación"
print("Estoy haciendo la \(😭)")
print(strResult)
print(strResult2)
print(result)

let character = "z"
switch character {
case "a", "e", "i", "o", "u":
    print("Es vocal")
    break
default:
    print("Es consonante")
}

let temperature = 50
switch temperature {
case 65...75:
    print("The temperature is just right")
    break
case ...64: //Int.min...64
    print("it's too cold...")
    break
default:
    print("It's too hot...")
}

func displayPi() {
    print("3.1415926535")
}

displayPi()

func triple(value: Int){
    let result = value * 3
    print("If you multiply \(value) by 3, you'll get \(result).")
}

triple(value: 10)

func multiply(firstNumber: Int, secondNumber: Int) -> Int{
    return firstNumber * secondNumber
}

result = multiply(firstNumber: 40, secondNumber: 20)
print(result)

func display(teamName: String, score: Int = 0){
    print("\(teamName): \(score)")
}

display(teamName: "Wombats", score: 100)
display(teamName: "Wombats")

//Estructuras Salvajeees uuuhh
struct Girl{
    var olor: String
    var name: String
    func sayHello() {
        print("Oda soy \(name) crika y tengo olor a \(olor)")
    }
}

let girl = Girl(olor: "cheetos", name: "Sofi")
print(girl)
print(girl.name)
print(girl.olor)
girl.sayHello()

struct Temperatura {
    var celsius: Double
    init(celsius: Double){
        self.celsius = celsius
    }
    init(fahrenheit: Double){
        self.celsius = (fahrenheit - 32) / 1.8
    }
    init(kelvin: Double){
        self.celsius = kelvin - 273.15
    }
    init(){
        self.celsius = 10.0
    }
}

let temp = Temperatura(celsius: 37.5)
let temp2 = Temperatura(fahrenheit: 96.5)
let temp3 = Temperatura()


