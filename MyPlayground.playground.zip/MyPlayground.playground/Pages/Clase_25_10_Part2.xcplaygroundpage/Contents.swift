import UIKit

protocol Drink{
    var volume: Double {get set}
    var caffeine: Double {get set}
    var temperature: Double {get set}
    var drinkSize: DrinkSize {get set}
    var description: String {get set}
}

enum DrinkSize{
    case can330, can235, can650, can473
}

extension Drink{
    mutating func drinking(amount: Double){
        //volume = volume - amount
        volume -= amount
    }
    mutating func temperatureChange(change: Double){
        temperature += change
    }
}

struct Monster: Drink{
    
    var volume: Double
    var caffeine: Double
    var temperature: Double
    var DrinkSize: DrinkSize
    var description: String
    
    init(temperature:Double){
        self.volume = 473
        self.caffeine = 0.5
        self.temperature = temperature
        self.description = "Bebida para salvar el semestre"
        self.DrinkSize = .can473
    }
    
}

struct Coca: Drink{
    
    var volume: Double
    var caffeine: Double
    var temperature: Double
    var DrinkSize: DrinkSize
    var description: String
    
    init(volume: Double, temperature:Double, drinkSize: DrinkSize){
        self.volume = volume
        self.caffeine = 0
        self.temperature = temperature
        self.description = "El favorito de Sofi"
        self.DrinkSize = drinkSize
    }
    
}

class Cooler{
    var temperature: Double
    var cansOfDrinks = [Drink]()
    var maxCans: Int
    
    init(temperature: Double, maxCans: Int) {
        self.temperature = temperature
        self.maxCans = maxCans
    }
    
    func addDrink(drink: Drink) -> Bool{
        if cansOfDrinks.count < maxCans{
            cansOfDrinks.append(drink)
            return true
        }else{
            print("El refi ta lleno, anonosh")
            return false
        }
    }
    
    func removeDrink() -> Drink?{
        if cansOfDrinks.count > 0 {
            return cansOfDrinks.removeFirst()
        }else{
            return nil
        }
    }
}

let refriOS = Cooler.init(temperature: 10, maxCans: 40)

for _ in 0...5{
    let moraBeverage = Monster(temperature: 20)
    refriOS.addDrink(drink: moraBeverage)
}

for _ in 0...5{
    let sofiBeverage = Coca(temperature: 20)
    refriOS.addDrink(drink: sofiBeverage)
}

print(refriOS.cansOfDrinks)

