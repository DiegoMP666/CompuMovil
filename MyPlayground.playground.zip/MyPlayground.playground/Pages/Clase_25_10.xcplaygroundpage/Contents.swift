import Foundation
import UIKit

class Shoe: CustomStringConvertible{
    
    var description: String{
        return "Shoe -> Size: \(size), Brand: \(brand), color: \(color)"
    }
    
    let size: Double
    let brand: String
    let color: String
    
    init(color: String, brand: String, size: Double){
        self.color = color
        self.brand = brand
        self.size = size
    }
    
}

let myShoe = Shoe(color: "Orange", brand: "Nike", size: 8.5)
let juanShoe = Shoe(color: "Grey", brand: "DC", size: 6.5)

print(myShoe)
print(juanShoe)

protocol Saltar{
    func salta()
}

protocol Sanar{
    func sana()
}

class Jugador: Saltar{
    func salta(){
        print("Salto como jugador")
    }
}

class Guerrero: Saltar{
    func salta(){
        print("Salto como guerrero")
    }
}

class Mago: Saltar{
    func salta(){
        print("Salto como mago")
    }
    func sana(){
        print("Te salva la vida")
    }
}

var oz = Mago()
var aquiles = Guerrero()

func hazloSaltar(saltador: Saltar){
    saltador.salta()
}


hazloSaltar(saltador: oz)
hazloSaltar(saltador: aquiles)
