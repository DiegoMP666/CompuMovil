//: [Previous](@previous)

import Foundation
struct Temperature {
    var celsius: Double
    var fahrenheit: Double
    var kelvin: Double
    init(celsius: Double){
        self.celsius = celsius
        fahrenheit = (celsius * 1.8) + 32
        kelvin = celsius + 273.15
    }
    init(fahrenheit: Double){
        celsius = (fahrenheit - 32) / 1.8
        self.fahrenheit = fahrenheit
        kelvin = ((self.fahrenheit - 32) / 1.8) + 273.15
    }
    init(kelvin: Double){
        celsius = kelvin - 273.15
        fahrenheit = (kelvin - 273.15) * 1.8 + 32
        self.kelvin = kelvin
    }
}

let temperature = Temperature(celsius: 18.5)
print(temperature)

//: [Next](@next)
