//: [Previous](@previous)

import Foundation
struct StepCounter{
    var totalSteps:Int = 0 { //Valor Default
        willSet {
            print("About to set totalSteps to \(newValue)")
        }
        didSet {
            print("Added \(totalSteps - oldValue) steps")
        }
    }
}

var stepCounter = StepCounter()
print(stepCounter)
stepCounter.totalSteps = 20
stepCounter.totalSteps = 40
stepCounter.totalSteps = 60

//: [Next](@next)
