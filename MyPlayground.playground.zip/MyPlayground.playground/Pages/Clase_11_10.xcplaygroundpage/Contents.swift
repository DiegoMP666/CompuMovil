import Foundation

for index in 1...10{
    print("\(index) times 5 is \(index * 5)")
}

let nombres = ["Aboites", "Sofi", "🧀🧀", "Juanito", "Dieguito", "James"]

for name in nombres{
    print("My name is \(name)")
}

var numeroDeVidas = 3

while numeroDeVidas > 0 {
    print("AÙN TENGO \(numeroDeVidas) VIDAS")
    numeroDeVidas -= 1
}
print("Me hicieron la morisión")

enum coordenadas {
    case norte
    case sur
    case este
    case oeste
}

enum comida {
    case sopa, carne, postre
}

var aDondeVoy: coordenadas = .norte

switch aDondeVoy {
case .norte:
    print("Voy al \(aDondeVoy)")
case .sur:
    print("Voy al \(aDondeVoy)")
case .este:
    print("Voy al \(aDondeVoy)")
case .oeste:
    print("Voy al \(aDondeVoy)")
}

struct pelicula{
    var nombre: String
}

enum ruedas: Int {
    case una, dos, tres, cuatro = 4
}

enum ruedas2 {
    case una (Int)
    case dos (Int)
    case tres (String)
    case cuatro (Double)
}

ruedas.cuatro.rawValue
ruedas.tres.rawValue
ruedas2.cuatro

struct Pagina {
    var tipoLetra: String
    var tamaño: Int
}

struct Libro {
    var numeroPaginas: Int
    var titulo: String
    var paginas: [Pagina]
}

var paginasLibro = [Pagina(tipoLetra: "Arial", tamaño: 5), Pagina(tipoLetra: "Baskerville", tamaño: 10)]

var names = ["Manuel", "Grecia", "Sofía"]
names.append("Mora")
names.count
names[2]
names.insert("Ilse", at: 2)
names[2]

var myDict = [String: Int]()
var myDict2 = Dictionary<String, Int>()
var myDict3: [String: Int] = [:]

var scores = ["Manuel": 10, "Mora": 8]
scores["Mora"]
scores.updateValue(6, forKey: "Mora")
scores["Mora"]

if let score = scores["Pedro"]{
    print(score)
}else {
    print("No ta")
}
